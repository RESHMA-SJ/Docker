<?php
echo "I love Docker Compose \n\n";